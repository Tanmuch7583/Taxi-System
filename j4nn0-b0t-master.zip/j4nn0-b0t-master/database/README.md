# Database

### list.db

It is composed by a single table, `REMINDERS`:

- `CHATID`: chat id for that user.
- `USRNAME`: username of the user.
- `ITEM`: the item added by the user.
    
Every time a user add/remove one or more item, these are added/removed to the db.

# More

Download [DB Browser for SQLite](https://sqlitebrowser.org) to see and modify these databases. 
